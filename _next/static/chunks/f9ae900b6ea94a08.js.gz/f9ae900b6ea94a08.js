(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,34424,e=>{"use strict";var t=(0,e.i(19524).__name)(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,"getIconStyles");e.s(["getIconStyles",()=>t])},69696,e=>{"use strict";var t=e.i(95727),l=e.i(26290);e.s(["channel",0,(e,o)=>t.default.lang.round(l.default.parse(e)[o])],69696)}]);